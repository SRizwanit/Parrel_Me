.class public final Lcom/excelliance/kxqp/util/kk$c;
.super Ljava/lang/Object;
.source "UpdateUtil.kt"

# interfaces
.implements Lcom/excelliance/kxqp/util/h6$d;


# annotations
.annotation system Ldalvik/annotation/EnclosingMethod;
    value = Lcom/excelliance/kxqp/util/kk;->K(Landroid/app/Activity;ZLn5/a;)V
.end annotation

.annotation system Ldalvik/annotation/InnerClass;
    accessFlags = 0x19
    name = null
.end annotation

.annotation runtime Lkotlin/Metadata;
    d1 = {
        "\u0000\u0017\n\u0000\n\u0002\u0018\u0002\n\u0002\u0018\u0002\n\u0000\n\u0002\u0018\u0002\n\u0002\u0008\u0004*\u0001\u0000\u0008\n\u0018\u00002\u00020\u0001J\u0017\u0010\u0005\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016\u00a2\u0006\u0004\u0008\u0005\u0010\u0006J\u0017\u0010\u0007\u001a\u00020\u00042\u0006\u0010\u0003\u001a\u00020\u0002H\u0016\u00a2\u0006\u0004\u0008\u0007\u0010\u0006\u00a8\u0006\u0008"
    }
    d2 = {
        "com/excelliance/kxqp/util/kk$c",
        "Lcom/excelliance/kxqp/util/h6$d;",
        "Landroid/app/Dialog;",
        "dialog",
        "Lve/j0;",
        "a",
        "(Landroid/app/Dialog;)V",
        "b",
        "commonMainAndExport_release"
    }
    k = 0x1
    mv = {
        0x2,
        0x1,
        0x0
    }
    xi = 0x30
.end annotation


# instance fields
.field final synthetic a:Z

.field final synthetic b:Landroid/app/Activity;

.field final synthetic c:Lcom/excelliance/kxqp/util/kk;

.field final synthetic d:Ln5/a;


# direct methods
.method constructor <init>(ZLandroid/app/Activity;Lcom/excelliance/kxqp/util/kk;Ln5/a;)V
    .locals 0

    .line 1
    iput-boolean p1, p0, Lcom/excelliance/kxqp/util/kk$c;->a:Z

    .line 2
    .line 3
    iput-object p2, p0, Lcom/excelliance/kxqp/util/kk$c;->b:Landroid/app/Activity;

    .line 4
    .line 5
    iput-object p3, p0, Lcom/excelliance/kxqp/util/kk$c;->c:Lcom/excelliance/kxqp/util/kk;

    .line 6
    .line 7
    iput-object p4, p0, Lcom/excelliance/kxqp/util/kk$c;->d:Ln5/a;

    .line 8
    .line 9
    invoke-static {p2}, Ldbg/D;->i(Landroid/content/Context;)V

    invoke-direct {p0}, Ljava/lang/Object;-><init>()V

    .line 10
    .line 11
    .line 12
    return-void
    .line 13
    .line 14
    .line 15
    .line 16
    .line 17
    .line 18
    .line 19
    .line 20
    .line 21
    .line 22
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
    .line 71
    .line 72
    .line 73
    .line 74
    .line 75
    .line 76
    .line 77
    .line 78
    .line 79
    .line 80
    .line 81
    .line 82
    .line 83
    .line 84
    .line 85
    .line 86
    .line 87
    .line 88
    .line 89
    .line 90
    .line 91
    .line 92
    .line 93
    .line 94
    .line 95
    .line 96
    .line 97
    .line 98
    .line 99
    .line 100
    .line 101
    .line 102
    .line 103
    .line 104
    .line 105
    .line 106
    .line 107
    .line 108
    .line 109
    .line 110
    .line 111
    .line 112
    .line 113
    .line 114
    .line 115
    .line 116
    .line 117
    .line 118
    .line 119
    .line 120
    .line 121
    .line 122
    .line 123
    .line 124
    .line 125
    .line 126
    .line 127
    .line 128
    .line 129
    .line 130
    .line 131
    .line 132
    .line 133
    .line 134
    .line 135
    .line 136
    .line 137
    .line 138
    .line 139
    .line 140
    .line 141
    .line 142
    .line 143
    .line 144
    .line 145
    .line 146
    .line 147
    .line 148
    .line 149
    .line 150
    .line 151
.end method


# virtual methods
.method public a(Landroid/app/Dialog;)V
    .locals 3

    .line 1
    const-string v0, "dialog"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/t;->j(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v1, p0, Lcom/excelliance/kxqp/util/kk$c;->b:Landroid/app/Activity;

    const-string v2, "kkc.a() Exit/No-thanks clicked: dismiss only"

    invoke-static {v1, v2}, Ldbg/D;->w(Landroid/content/Context;Ljava/lang/String;)V

    invoke-static {p1}, Lcom/excelliance/kxqp/util/c6;->f(Landroid/app/Dialog;)V

    .line 7
    .line 8
    .line 9
    return-void
    .line 19
    .line 20
    .line 21
.end method

.method public b(Landroid/app/Dialog;)V
    .locals 2

    .line 1
    const-string v0, "dialog"

    .line 2
    .line 3
    invoke-static {p1, v0}, Lkotlin/jvm/internal/t;->j(Ljava/lang/Object;Ljava/lang/String;)V

    .line 4
    .line 5
    .line 6
    iget-object v0, p0, Lcom/excelliance/kxqp/util/kk$c;->b:Landroid/app/Activity;

    const-string v1, "kkc.b() Update clicked"

    invoke-static {v0, v1}, Ldbg/D;->w(Landroid/content/Context;Ljava/lang/String;)V

    iget-boolean v0, p0, Lcom/excelliance/kxqp/util/kk$c;->a:Z

    .line 7
    .line 8
    if-nez v0, :cond_0

    .line 9
    .line 10
    invoke-static {p1}, Lcom/excelliance/kxqp/util/c6;->f(Landroid/app/Dialog;)V

    .line 11
    .line 12
    .line 13
    :cond_0
    iget-object p1, p0, Lcom/excelliance/kxqp/util/kk$c;->c:Lcom/excelliance/kxqp/util/kk;

    .line 14
    .line 15
    iget-object v0, p0, Lcom/excelliance/kxqp/util/kk$c;->b:Landroid/app/Activity;

    .line 16
    .line 17
    iget-object v1, p0, Lcom/excelliance/kxqp/util/kk$c;->d:Ln5/a;

    .line 18
    .line 19
    invoke-static {p1, v0, v1}, Lcom/excelliance/kxqp/util/kk;->r(Lcom/excelliance/kxqp/util/kk;Landroid/app/Activity;Ln5/a;)V

    const-string v1, "kkc.b() kk.r() returned"

    invoke-static {v0, v1}, Ldbg/D;->w(Landroid/content/Context;Ljava/lang/String;)V

    .line 20
    .line 21
    .line 22
    return-void
    .line 23
    .line 24
    .line 25
    .line 26
    .line 27
    .line 28
    .line 29
    .line 30
    .line 31
    .line 32
    .line 33
    .line 34
    .line 35
    .line 36
    .line 37
    .line 38
    .line 39
    .line 40
    .line 41
    .line 42
    .line 43
    .line 44
    .line 45
    .line 46
    .line 47
    .line 48
    .line 49
    .line 50
    .line 51
    .line 52
    .line 53
    .line 54
    .line 55
    .line 56
    .line 57
    .line 58
    .line 59
    .line 60
    .line 61
    .line 62
    .line 63
    .line 64
    .line 65
    .line 66
    .line 67
    .line 68
    .line 69
    .line 70
.end method
